// SBA Shaders: changes the game's light, fog and ambient colour to give it a
// different "look": day (original), sunset, night, pastel.
//
// How it works (simple version):
//   1. We hook UnityEngine.Camera.get_main. The game calls it all the time, so
//      it is a free "clock" that ticks on the main thread.
//   2. Every ~30 ticks we read our settings (enabled / style / strength).
//   3. If something changed (or the game loaded a new scene and reset the
//      lighting), we set RenderSettings (ambient, fog) and the sun Light.
//
// Everything is in this single file. Uses only the Bearite API + il2cpp.
#include "bearite.hpp"

#include <dirent.h>
#include <dlfcn.h>

#include <algorithm>
#include <cstdio>
#include <vector>

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <initializer_list>
#include <type_traits>
#include <cstdint>
#include <string>

namespace {

constexpr const char* TAG = "sba-shaders";
constexpr const char* ASM = "UnityEngine.CoreModule";

struct Color { float r, g, b, a; };

// ---- il2cpp functions we need (found with dlsym) -------------------------
void* (*rt_invoke)(void*, void*, void**, void**) = nullptr;
void* (*obj_unbox)(void*) = nullptr;

// ---- Unity methods (MethodInfo*), filled in init() -----------------------
struct M {
  void *set_ambient, *get_ambient;
  void *set_fog, *get_fog;
  void *set_fog_color, *get_fog_color;
  void *set_fog_density, *get_fog_density;
  void *set_fog_mode, *get_fog_mode;
  void *get_sun;
  void *light_set_color, *light_get_color;
  void *light_set_intensity, *light_get_intensity;
} m;

bool g_ready = false;

void* invoke(void* method, void* self, void** args) {
  if (!method || !rt_invoke) return nullptr;
  void* none[1] = {nullptr};
  void* exc = nullptr;
  void* r = rt_invoke(method, self, args ? args : none, &exc);
  return exc ? nullptr : r;
}

Color get_color(void* method, void* self = nullptr) {
  Color c{0, 0, 0, 1};
  void* b = invoke(method, self, nullptr);
  if (b) c = *static_cast<Color*>(obj_unbox(b));
  return c;
}
float get_float(void* method, void* self = nullptr) {
  void* b = invoke(method, self, nullptr);
  return b ? *static_cast<float*>(obj_unbox(b)) : 0.f;
}
int get_int(void* method, void* self = nullptr) {
  void* b = invoke(method, self, nullptr);
  return b ? *static_cast<int*>(obj_unbox(b)) : 0;
}
bool get_bool(void* method, void* self = nullptr) {
  void* b = invoke(method, self, nullptr);
  return b ? *static_cast<bool*>(obj_unbox(b)) : false;
}
void set_color(void* method, Color c, void* self = nullptr) { void* a[1] = {&c}; invoke(method, self, a); }
void set_float(void* method, float v, void* self = nullptr) { void* a[1] = {&v}; invoke(method, self, a); }
void set_int(void* method, int v, void* self = nullptr) { void* a[1] = {&v}; invoke(method, self, a); }
void set_bool(void* method, bool v, void* self = nullptr) { void* a[1] = {&v}; invoke(method, self, a); }

Color mix(Color a, Color b, float t) {
  return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, 1.f};
}
bool same(Color a, Color b) {
  return std::fabs(a.r - b.r) < 0.003f && std::fabs(a.g - b.g) < 0.003f && std::fabs(a.b - b.b) < 0.003f;
}

// ---- sky: Material.SetColor(string, Color) needs the exact overload ------
// bearite::find_method only knows the argument COUNT, and Material has two
// overloads (string and int). So we look it up ourselves by argument types.
struct Il {
  void* (*domain_get)();
  void* (*assembly_open)(void*, const char*);
  void* (*assembly_image)(void*);
  void* (*class_from_name)(void*, const char*, const char*);
  void* (*class_methods)(void*, void**);
  const char* (*method_name)(void*);
  uint32_t (*method_argc)(void*);
  void* (*method_param)(void*, uint32_t);
  char* (*type_name)(void*);
  void (*il_free)(void*);
  void* (*string_new)(const char*);
  bool ok = false;
} il;

bool init_il() {
  if (il.ok) return true;
  void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
  if (!h) h = RTLD_DEFAULT;
  auto sym = [&](const char* n, auto& out) { out = reinterpret_cast<std::remove_reference_t<decltype(out)>>(dlsym(h, n)); return out != nullptr; };
  il.ok = sym("il2cpp_domain_get", il.domain_get) && sym("il2cpp_domain_assembly_open", il.assembly_open) &&
          sym("il2cpp_assembly_get_image", il.assembly_image) && sym("il2cpp_class_from_name", il.class_from_name) &&
          sym("il2cpp_class_get_methods", il.class_methods) && sym("il2cpp_method_get_name", il.method_name) &&
          sym("il2cpp_method_get_param_count", il.method_argc) && sym("il2cpp_method_get_param", il.method_param) &&
          sym("il2cpp_type_get_name", il.type_name) && sym("il2cpp_free", il.il_free) && sym("il2cpp_string_new", il.string_new);
  return il.ok;
}

void* find_typed(const char* asm_name, const char* ns, const char* klass, const char* name,
                 std::initializer_list<const char*> params) {
  if (!init_il()) return nullptr;
  void* a = il.assembly_open(il.domain_get(), asm_name);
  void* img = a ? il.assembly_image(a) : nullptr;
  void* k = img ? il.class_from_name(img, ns, klass) : nullptr;
  if (!k) return nullptr;
  void* iter = nullptr;
  while (void* mi = il.class_methods(k, &iter)) {
    if (strcmp(il.method_name(mi), name) != 0 || il.method_argc(mi) != params.size()) continue;
    bool match = true;
    uint32_t i = 0;
    for (const char* want : params) {
      char* tn = il.type_name(il.method_param(mi, i++));
      if (!tn || strcmp(tn, want) != 0) match = false;
      if (tn) il.il_free(tn);
      if (!match) break;
    }
    if (match) return mi;
  }
  return nullptr;
}

void *m_get_skybox = nullptr, *m_mat_has = nullptr, *m_mat_set = nullptr, *m_mat_get = nullptr;
const char* kSkyProps[] = {"_Tint", "_SkyTint", "_Color"};

struct SkySaved { void* mat = nullptr; Color orig[3]; bool has[3] = {false, false, false}; } sky_saved;

bool mat_has(void* mat, const char* prop) {
  void* a[1] = {il.string_new(prop)};
  void* b = invoke(m_mat_has, mat, a);
  return b && *static_cast<bool*>(obj_unbox(b));
}

// t = 0..1. Mix between the original sky tint and `target`.
void set_sky(const Color* target, float t) {
  if (!m_get_skybox || !m_mat_has || !m_mat_set || !m_mat_get) return;
  void* mat = invoke(m_get_skybox, nullptr, nullptr);
  if (!mat) return;
  if (sky_saved.mat != mat) {  // a new sky material: remember its original colours
    sky_saved = SkySaved{};
    sky_saved.mat = mat;
    for (int i = 0; i < 3; ++i) {
      if (!mat_has(mat, kSkyProps[i])) continue;
      void* a[1] = {il.string_new(kSkyProps[i])};
      void* b = invoke(m_mat_get, mat, a);
      if (b) { sky_saved.orig[i] = *static_cast<Color*>(obj_unbox(b)); sky_saved.has[i] = true; }
    }
  }
  for (int i = 0; i < 3; ++i) {
    if (!sky_saved.has[i]) continue;
    Color c = target ? mix(sky_saved.orig[i], *target, t) : sky_saved.orig[i];
    void* a[2] = {il.string_new(kSkyProps[i]), &c};
    invoke(m_mat_set, mat, a);
  }
}

bool init() {
  if (g_ready) return true;
  void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
  if (!h) h = RTLD_DEFAULT;
  rt_invoke = reinterpret_cast<decltype(rt_invoke)>(dlsym(h, "il2cpp_runtime_invoke"));
  obj_unbox = reinterpret_cast<decltype(obj_unbox)>(dlsym(h, "il2cpp_object_unbox"));
  if (!rt_invoke || !obj_unbox) {
    bearite::log(BEARITE_LOG_ERROR, TAG, "il2cpp exports not found");
    return false;
  }
  auto rs = [](const char* name, int argc) { return bearite::find_method(ASM, "UnityEngine", "RenderSettings", name, argc); };
  auto lt = [](const char* name, int argc) { return bearite::find_method(ASM, "UnityEngine", "Light", name, argc); };
  m.set_ambient = rs("set_ambientLight", 1);
  m.get_ambient = rs("get_ambientLight", 0);
  m.set_fog = rs("set_fog", 1);
  m.get_fog = rs("get_fog", 0);
  m.set_fog_color = rs("set_fogColor", 1);
  m.get_fog_color = rs("get_fogColor", 0);
  m.set_fog_density = rs("set_fogDensity", 1);
  m.get_fog_density = rs("get_fogDensity", 0);
  m.set_fog_mode = rs("set_fogMode", 1);
  m.get_fog_mode = rs("get_fogMode", 0);
  m.get_sun = rs("get_sun", 0);
  m.light_set_color = lt("set_color", 1);
  m.light_get_color = lt("get_color", 0);
  m.light_set_intensity = lt("set_intensity", 1);
  m.light_get_intensity = lt("get_intensity", 0);
  if (!m.set_ambient || !m.get_ambient || !m.set_fog || !m.set_fog_color) {
    bearite::log(BEARITE_LOG_ERROR, TAG, "RenderSettings methods not found");
    return false;
  }
  m_get_skybox = rs("get_skybox", 0);
  m_mat_has = find_typed(ASM, "UnityEngine", "Material", "HasProperty", {"System.String"});
  m_mat_set = find_typed(ASM, "UnityEngine", "Material", "SetColor", {"System.String", "UnityEngine.Color"});
  m_mat_get = find_typed(ASM, "UnityEngine", "Material", "GetColor", {"System.String"});
  bearite::log(BEARITE_LOG_INFO, TAG, "sky methods: skybox=%d has=%d set=%d get=%d", m_get_skybox != nullptr,
               m_mat_has != nullptr, m_mat_set != nullptr, m_mat_get != nullptr);
  // Which graphics API does the game use? (8=GLES2, 11=GLES3, 21=Vulkan)
  if (void* gd = bearite::find_method(ASM, "UnityEngine", "SystemInfo", "get_graphicsDeviceType", 0)) {
    bearite::log(BEARITE_LOG_INFO, TAG, "GRAPHICS API id = %d (11 = OpenGL ES 3, 21 = Vulkan)", get_int(gd));
  }
  g_ready = true;
  return true;
}

// ---- styles --------------------------------------------------------------
struct Preset {
  Color sun;        // sun light colour
  float sun_mult;   // sun brightness multiplier
  Color ambient;    // ambient (shadow) light colour
  Color fog;        // fog colour
  float density;    // fog thickness
  Color sky;        // sky tint (only if the sky is a Skybox material)
};

bool get_preset(const std::string& style, Preset& p) {
  if (style == "sunset") { p = {{1.00f, 0.55f, 0.25f, 1}, 1.10f, {0.85f, 0.50f, 0.45f, 1}, {0.95f, 0.50f, 0.35f, 1}, 0.006f, {1.00f, 0.60f, 0.40f, 1}}; return true; }
  if (style == "night")  { p = {{0.35f, 0.45f, 0.90f, 1}, 0.25f, {0.12f, 0.16f, 0.35f, 1}, {0.04f, 0.07f, 0.18f, 1}, 0.012f, {0.10f, 0.15f, 0.40f, 1}}; return true; }
  if (style == "pastel") { p = {{1.00f, 0.95f, 0.95f, 1}, 1.00f, {1.00f, 0.85f, 0.90f, 1}, {0.85f, 0.90f, 1.00f, 1}, 0.004f, {0.90f, 0.80f, 0.95f, 1}}; return true; }
  return false;  // "day" = original
}

// ---- shader packs: files <mod dir>/shaderpacks/*.json ---------------------
struct Pack { std::string file, name; Preset p; };
std::vector<Pack> g_packs;
bool g_packs_loaded = false;

std::string read_file(const std::string& path) {
  std::string out;
  if (FILE* f = fopen(path.c_str(), "rb")) {
    char buf[2048];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    fclose(f);
  }
  return out;
}

// Reads `count` numbers after "key": [ ... ] (or one number if count == 1).
bool json_nums(const std::string& j, const char* key, int count, float* out) {
  std::string k = std::string("\"") + key + "\"";
  size_t p = j.find(k);
  if (p == std::string::npos) return false;
  p = j.find(':', p + k.size());
  if (p == std::string::npos) return false;
  ++p;
  for (int i = 0; i < count; ++i) {
    while (p < j.size() && (j[p] == ' ' || j[p] == '[' || j[p] == ',' || j[p] == '\n' || j[p] == '\r' || j[p] == '\t')) ++p;
    char* end = nullptr;
    out[i] = strtof(j.c_str() + p, &end);
    if (end == j.c_str() + p) return false;
    p = end - j.c_str();
  }
  return true;
}

std::string json_name(const std::string& j) {
  size_t p = j.find("\"name\"");
  if (p == std::string::npos) return "";
  p = j.find(':', p);
  p = j.find('"', p);
  if (p == std::string::npos) return "";
  size_t e = j.find('"', p + 1);
  return e == std::string::npos ? "" : j.substr(p + 1, e - p - 1);
}

void load_packs() {
  if (g_packs_loaded) return;
  g_packs_loaded = true;
  const BeariteApi* a = bearite::api();
  std::string dir = (a && a->mod_dir) ? a->mod_dir : "";
  while (dir.size() > 1 && dir.back() == '/') dir.pop_back();
  dir += "/shaderpacks";
  std::vector<std::string> files;
  if (DIR* d = opendir(dir.c_str())) {
    while (dirent* e = readdir(d)) {
      std::string n = e->d_name;
      if (n.size() > 5 && n.substr(n.size() - 5) == ".json") files.push_back(n);
    }
    closedir(d);
  } else {
    bearite::log(BEARITE_LOG_WARN, TAG, "no shaderpacks folder: %s", dir.c_str());
  }
  std::sort(files.begin(), files.end());
  for (const std::string& f : files) {
    std::string j = read_file(dir + "/" + f);
    float sun[3], amb[3], fog[3], mult = 1.f, dens = 0.005f;
    if (!json_nums(j, "sun", 3, sun) || !json_nums(j, "ambient", 3, amb) || !json_nums(j, "fog", 3, fog)) {
      bearite::log(BEARITE_LOG_WARN, TAG, "pack %s: needs sun, ambient, fog (3 numbers each)", f.c_str());
      continue;
    }
    json_nums(j, "sun_mult", 1, &mult);
    json_nums(j, "density", 1, &dens);
    float sky[3] = {fog[0], fog[1], fog[2]};
    json_nums(j, "sky", 3, sky);
    Pack pk;
    pk.file = f;
    pk.name = json_name(j);
    if (pk.name.empty()) pk.name = f;
    pk.p = {{sun[0], sun[1], sun[2], 1}, mult, {amb[0], amb[1], amb[2], 1}, {fog[0], fog[1], fog[2], 1}, dens, {sky[0], sky[1], sky[2], 1}};
    g_packs.push_back(pk);
    bearite::log(BEARITE_LOG_INFO, TAG, "pack %zu = %s (%s)", g_packs.size(), pk.name.c_str(), f.c_str());
  }
  if (g_packs.empty()) bearite::log(BEARITE_LOG_INFO, TAG, "no packs found in %s", dir.c_str());
}

// The original values of the current scene (so "day" can restore them).
struct Saved {
  bool have = false;
  Color ambient{}, fog{}, sun{};
  bool fog_on = false;
  float density = 0, sun_i = 1;
  int mode = 1;
} saved;

Color g_last_ambient{-1, -1, -1, 1};  // the ambient colour we set last time
std::string g_last_key;
int g_tick = 0;

void* sun_light() { return invoke(m.get_sun, nullptr, nullptr); }

void capture_originals() {
  saved.ambient = get_color(m.get_ambient);
  saved.fog = get_color(m.get_fog_color);
  saved.fog_on = get_bool(m.get_fog);
  saved.density = get_float(m.get_fog_density);
  saved.mode = get_int(m.get_fog_mode);
  if (void* sun = sun_light()) {
    saved.sun = get_color(m.light_get_color, sun);
    saved.sun_i = get_float(m.light_get_intensity, sun);
  }
  saved.have = true;
}

void apply_style(bool is_style, const Preset& p, float t) {
  void* sun = sun_light();
  if (!is_style) {  // restore the original look
    set_color(m.set_ambient, saved.ambient);
    set_bool(m.set_fog, saved.fog_on);
    set_color(m.set_fog_color, saved.fog);
    set_float(m.set_fog_density, saved.density);
    set_int(m.set_fog_mode, saved.mode);
    if (sun) { set_color(m.light_set_color, saved.sun, sun); set_float(m.light_set_intensity, saved.sun_i, sun); }
    set_sky(nullptr, 0);
    g_last_ambient = saved.ambient;
    return;
  }
  Color amb = mix(saved.ambient, p.ambient, t);
  set_color(m.set_ambient, amb);
  set_bool(m.set_fog, true);
  set_int(m.set_fog_mode, 3);  // FogMode.ExponentialSquared
  set_color(m.set_fog_color, mix(saved.fog, p.fog, t));
  set_float(m.set_fog_density, saved.density + (p.density - saved.density) * t);
  if (sun) {
    set_color(m.light_set_color, mix(saved.sun, p.sun, t), sun);
    set_float(m.light_set_intensity, saved.sun_i * (1.f + (p.sun_mult - 1.f) * t), sun);
  }
  set_sky(&p.sky, t);
  g_last_ambient = amb;
}

void tick() {
  if (!init()) return;
  std::string en = bearite::setting("enabled", "true");
  bool enabled = (en == "true" || en == "1" || en == "True");
  std::string style = bearite::setting("style", "day");
  float t = static_cast<float>(atof(bearite::setting("strength", "1").c_str()));
  int pack_no = atoi(bearite::setting("pack", "0").c_str());  // 0 = built-in style
  if (t < 0) t = 0;
  if (t > 1) t = 1;
  load_packs();
  Preset preset{};
  bool is_style = false;
  if (!enabled) {
    style = "day";
    pack_no = 0;
  } else if (pack_no >= 1 && pack_no <= static_cast<int>(g_packs.size())) {
    preset = g_packs[pack_no - 1].p;
    is_style = true;
    style = "pack" + std::to_string(pack_no);
  } else {
    is_style = get_preset(style, preset);
  }

  // A new scene resets the lighting. Then the current ambient is not the one
  // we set, so these are the new originals.
  Color now = get_color(m.get_ambient);
  bool scene_changed = !saved.have || !same(now, g_last_ambient);
  if (scene_changed) {
    capture_originals();
    g_last_key.clear();
  }
  std::string key = style + "|" + std::to_string(t);
  if (key == g_last_key) return;
  g_last_key = key;
  apply_style(is_style, preset, t);
  bearite::log(BEARITE_LOG_INFO, TAG, "style=%s strength=%.1f", style.c_str(), t);
}

// ---- the hook ------------------------------------------------------------
void* (*orig_get_main)(void*) = nullptr;

void* hk_get_main(void* method_info) {
  void* cam = orig_get_main ? orig_get_main(method_info) : nullptr;
  if (++g_tick >= 30) {
    g_tick = 0;
    tick();
  }
  return cam;
}

}  // namespace

// Entry point. IMPORTANT: copy the exact signature from your hello-mod / mod-menu.
extern "C" __attribute__((visibility("default"))) void bearite_on_load(const BeariteApi* api) {
  bearite::init(api);
  bool ok = bearite::hook(ASM, "UnityEngine", "Camera", "get_main", 0,
                          reinterpret_cast<void*>(&hk_get_main),
                          reinterpret_cast<void**>(&orig_get_main));
  bearite::log(ok ? BEARITE_LOG_INFO : BEARITE_LOG_ERROR, TAG, ok ? "loaded" : "hook failed");
}
