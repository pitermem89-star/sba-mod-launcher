Bearite Patcher (Android, Material 3)
Put this patcher.zip into the repo root and commit.
GitHub Actions (build-patcher-zip.yml) unpacks it and builds the APK.
Inside: Gradle project + prebuilt/ (libmain.so, libbearite.so, sign.p12).
