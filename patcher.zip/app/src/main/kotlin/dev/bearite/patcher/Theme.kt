package dev.bearite.patcher

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Warm "honey" palette used on Android < 12; on 12+ the system (Material You) colors win.
private val Light = lightColorScheme(
    primary = Color(0xFF7A5900), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFDEA6), onPrimaryContainer = Color(0xFF261900),
    secondary = Color(0xFF6C5C3F), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF5DFBB), onSecondaryContainer = Color(0xFF241A04),
    tertiary = Color(0xFF4E6540), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFD0EBBB), onTertiaryContainer = Color(0xFF0B2005),
    background = Color(0xFFFFFBFF), onBackground = Color(0xFF1F1B16),
    surface = Color(0xFFFFFBFF), onSurface = Color(0xFF1F1B16),
    surfaceVariant = Color(0xFFEEE0CF), onSurfaceVariant = Color(0xFF4E4639),
    error = Color(0xFFBA1A1A), onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFFFBA2D), onPrimary = Color(0xFF402D00),
    primaryContainer = Color(0xFF5C4200), onPrimaryContainer = Color(0xFFFFDEA6),
    secondary = Color(0xFFD8C4A0), onSecondary = Color(0xFF3A2F15),
    secondaryContainer = Color(0xFF53452A), onSecondaryContainer = Color(0xFFF5DFBB),
    tertiary = Color(0xFFB5CFA0), onTertiary = Color(0xFF213616),
    tertiaryContainer = Color(0xFF374D2B), onTertiaryContainer = Color(0xFFD0EBBB),
    background = Color(0xFF16130E), onBackground = Color(0xFFE9E1D9),
    surface = Color(0xFF16130E), onSurface = Color(0xFFE9E1D9),
    surfaceVariant = Color(0xFF4E4639), onSurfaceVariant = Color(0xFFD2C5B4),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
)

@Composable
fun BeariteTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
