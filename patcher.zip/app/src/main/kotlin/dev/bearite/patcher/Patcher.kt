package dev.bearite.patcher

import android.content.Context
import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import com.android.apksig.ApkSigner

/** What we found inside the chosen APK. */
data class Analysis(
    val sizeMb: Long,
    val entries: Int,
    val arm64: Boolean,
    val il2cpp: Boolean,
    val unityMain: Boolean,
    val alreadyPatched: Boolean,
) {
    /** null = the APK can be patched, otherwise a human readable reason. */
    val problem: String?
        get() = when {
            alreadyPatched -> "Этот APK уже пропатчен Bearite"
            !arm64 -> "Нет папки lib/arm64-v8a. Нужен полный APK (не split), 64-бит"
            !unityMain -> "Не найден lib/arm64-v8a/libmain.so. Это не Unity-игра?"
            !il2cpp -> "Не найден libil2cpp.so. Нужна IL2CPP-сборка игры"
            else -> null
        }
}

object Patcher {
    private const val DIR = "lib/arm64-v8a/"
    private const val MAIN = DIR + "libmain.so"
    private const val REAL = DIR + "libmain_real.so"
    private const val BEARITE = DIR + "libbearite.so"
    private const val IL2CPP = DIR + "libil2cpp.so"

    fun analyze(apk: File): Analysis = ZipFile(apk).use { z ->
        val names = z.entries().asSequence().map { it.name }.toHashSet()
        Analysis(
            sizeMb = apk.length() / (1024 * 1024),
            entries = names.size,
            arm64 = names.any { it.startsWith(DIR) },
            il2cpp = IL2CPP in names,
            unityMain = MAIN in names,
            alreadyPatched = REAL in names || BEARITE in names,
        )
    }

    fun assetsReady(ctx: Context): String? {
        for (n in listOf("libmain.so", "libbearite.so", "sign.p12")) {
            val ok = try { ctx.assets.open(n).use { true } } catch (e: Exception) { false }
            if (!ok) return "В приложение не вшит файл $n (см. сборку на GitHub)"
        }
        return null
    }

    private class Counting(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    /** Extra field that pads the local header so the entry data starts at a multiple of `align`. */
    private fun padding(offsetBeforeHeader: Long, name: String, align: Int): ByteArray {
        val base = offsetBeforeHeader + 30 + name.toByteArray(Charsets.UTF_8).size
        var need = ((align - base % align) % align).toInt()
        if (need == 0) return ByteArray(0)
        if (need < 4) need += align
        val extra = ByteArray(need)
        extra[0] = 0x35; extra[1] = 0xD9.toByte()           // zipalign's extra id 0xD935
        extra[2] = ((need - 4) and 0xFF).toByte()
        extra[3] = (((need - 4) shr 8) and 0xFF).toByte()
        return extra
    }

    private fun isOldSignature(name: String): Boolean {
        if (!name.startsWith("META-INF/")) return false
        val n = name.uppercase()
        return n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") ||
            n.endsWith(".DSA") || n.endsWith(".EC")
    }

    private fun putStored(
        zos: ZipOutputStream, cnt: Counting, name: String, data: ByteArray, time: Long, align: Int,
    ) {
        val crc = CRC32().apply { update(data) }
        val e = ZipEntry(name)
        e.method = ZipEntry.STORED
        e.size = data.size.toLong()
        e.compressedSize = data.size.toLong()
        e.crc = crc.value
        if (time > 0) e.time = time
        zos.closeEntry()
        val pad = padding(cnt.count, name, align)
        if (pad.isNotEmpty()) e.extra = pad
        zos.putNextEntry(e)
        zos.write(data)
        zos.closeEntry()
    }

    fun patch(ctx: Context, input: File, output: File, log: (String) -> Unit, progress: (Float) -> Unit) {
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        unsigned.delete()
        output.parentFile?.mkdirs()
        output.delete()

        val libMain = ctx.assets.open("libmain.so").use { it.readBytes() }
        val libBearite = ctx.assets.open("libbearite.so").use { it.readBytes() }

        log("Собираю APK: libmain.so -> libmain_real.so, добавляю прокси и загрузчик")
        ZipFile(input).use { zip ->
            val all = zip.entries().asSequence().toList()
            val total = all.size.toFloat()
            val cnt = Counting(unsigned.outputStream().buffered(1 shl 16))
            val zos = ZipOutputStream(cnt)
            zos.setLevel(Deflater.BEST_SPEED)
            var done = 0
            val buf = ByteArray(1 shl 16)
            var skipped = 0

            for (src in all) {
                done++
                if (done % 50 == 0 || done == all.size) progress(0.05f + 0.75f * done / total)
                if (src.isDirectory) continue
                if (isOldSignature(src.name)) { skipped++; continue }

                // the game's own libmain.so is kept under a new name; our proxy takes its place
                val outName = if (src.name == MAIN) REAL else src.name
                val stored = src.method == ZipEntry.STORED
                val e = ZipEntry(outName)
                if (src.time > 0) e.time = src.time
                zos.closeEntry()
                if (stored) {
                    e.method = ZipEntry.STORED
                    e.size = src.size
                    e.compressedSize = src.size
                    e.crc = src.crc
                    val align = if (outName.endsWith(".so")) 4096 else 4
                    val pad = padding(cnt.count, outName, align)
                    if (pad.isNotEmpty()) e.extra = pad
                } else {
                    e.method = ZipEntry.DEFLATED
                }
                zos.putNextEntry(e)
                zip.getInputStream(src).use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        zos.write(buf, 0, n)
                    }
                }
                zos.closeEntry()
            }
            putStored(zos, cnt, MAIN, libMain, System.currentTimeMillis(), 4096)
            putStored(zos, cnt, BEARITE, libBearite, System.currentTimeMillis(), 4096)
            zos.close()
            log("Старая подпись удалена ($skipped файлов), записано ${all.size} записей")
        }
        progress(0.82f)

        log("Подписываю APK")
        val pw = "bearite".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("sign.p12").use { ks.load(it, pw) }
        val alias = ks.aliases().nextElement()
        val key = ks.getKey(alias, pw) as PrivateKey
        val chain = ks.getCertificateChain(alias).map { it as X509Certificate }
        val cfg = ApkSigner.SignerConfig.Builder("bearite", key, chain).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(unsigned)
            .setOutputApk(output)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
        unsigned.delete()
        progress(1f)
        log("Готово: ${output.name} (${output.length() / (1024 * 1024)} МБ)")
    }
}
