package dev.bearite.patcher

import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Phase { Idle, Copying, Ready, Patching, Done, Failed }

class PatcherVm(app: Application) : AndroidViewModel(app) {
    var phase by mutableStateOf(Phase.Idle)
    var fileName by mutableStateOf("")
    var analysis by mutableStateOf<Analysis?>(null)
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf<String?>(null)
    var result by mutableStateOf<File?>(null)
    val log = mutableStateListOf<String>()
    val assetsProblem: String? = Patcher.assetsReady(app)

    private val ctx get() = getApplication<Application>()
    private val input get() = File(ctx.cacheDir, "input.apk")

    private fun fail(e: Throwable) {
        error = e.message ?: e.javaClass.simpleName
        phase = Phase.Failed
    }

    fun reset() {
        phase = Phase.Idle; analysis = null; error = null; result = null
        progress = 0f; fileName = ""; log.clear()
        input.delete()
    }

    private fun displayName(uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "game.apk"
        }
        return "game.apk"
    }

    fun pick(uri: Uri) {
        phase = Phase.Copying; error = null; log.clear(); progress = 0f; result = null; analysis = null
        viewModelScope.launch {
            try {
                val (name, info) = withContext(Dispatchers.IO) {
                    val n = displayName(uri)
                    val dst = input
                    dst.delete()
                    val ins = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Не удалось открыть файл")
                    ins.use { i -> dst.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                    n to Patcher.analyze(dst)
                }
                fileName = name; analysis = info; phase = Phase.Ready
            } catch (e: Throwable) {
                fail(e)
            }
        }
    }

    fun patch() {
        if (phase != Phase.Ready) return
        phase = Phase.Patching; progress = 0f; log.clear(); error = null
        val base = fileName.removeSuffix(".apk").ifBlank { "game" }
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "patched")
        val out = File(dir, "$base-bearite.apk")
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    Patcher.patch(
                        ctx, input, out,
                        log = { line -> viewModelScope.launch(Dispatchers.Main) { log.add(line) } },
                        progress = { p -> progress = p },
                    )
                }
                input.delete()
                result = out; phase = Phase.Done
            } catch (e: Throwable) {
                fail(e)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BeariteTheme {
                val vm: PatcherVm = viewModel()
                PatcherScreen(vm)
            }
        }
    }
}
