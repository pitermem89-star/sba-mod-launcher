package dev.bearite.patcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatcherScreen(vm: PatcherVm) {
    val ctx = LocalContext.current
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.pick(uri)
    }
    val busy = vm.phase == Phase.Copying || vm.phase == Phase.Patching
    val info = vm.analysis

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Bearite Patcher", fontWeight = FontWeight.Bold) },
                scrollBehavior = scroll,
                actions = {
                    if (vm.phase != Phase.Idle && !busy) {
                        IconButton(onClick = vm::reset) { Icon(Icons.Filled.Refresh, contentDescription = "Заново") }
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Hero()
            vm.assetsProblem?.let { Notice(it, error = true) }

            StepCard(1, "Выбери APK игры", done = info != null) {
                Text(
                    "Нужен полный APK Super Bear Adventure (не split), 64-бит, IL2CPP.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (vm.phase == Phase.Copying) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Копирую APK…", style = MaterialTheme.typography.labelLarge)
                }
                if (vm.fileName.isNotBlank() && vm.phase != Phase.Copying) {
                    Text(vm.fileName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                }
                FilledTonalButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) {
                    Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (info == null) "Выбрать APK" else "Выбрать другой")
                }
            }

            AnimatedVisibility(info != null, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                if (info != null) {
                    StepCard(2, "Проверка", done = info.problem == null) {
                        CheckRow("64-бит (lib/arm64-v8a)", info.arm64)
                        CheckRow("Unity: libmain.so", info.unityMain)
                        CheckRow("IL2CPP: libil2cpp.so", info.il2cpp)
                        CheckRow("Ещё не патчен", !info.alreadyPatched)
                        Text(
                            "${info.sizeMb} МБ · ${info.entries} файлов",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        info.problem?.let { Notice(it, error = true) }
                    }
                }
            }

            AnimatedVisibility(
                info != null && info.problem == null,
                enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically(),
            ) {
                StepCard(3, "Патч", done = vm.phase == Phase.Done) {
                    if (vm.phase == Phase.Patching || vm.phase == Phase.Done) {
                        val p by animateFloatAsState(vm.progress, label = "progress")
                        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                        Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                        LogBox(vm.log)
                    } else {
                        Text(
                            "Добавит загрузчик Bearite в APK и подпишет его. Может занять около минуты.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Button(
                        onClick = vm::patch,
                        enabled = vm.phase == Phase.Ready && vm.assetsProblem == null,
                        modifier = Modifier.alpha(if (vm.phase == Phase.Done) 0.5f else 1f),
                    ) {
                        Icon(Icons.Filled.Done, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (vm.phase == Phase.Patching) "Патчу…" else "Пропатчить")
                    }
                }
            }

            AnimatedVisibility(vm.phase == Phase.Done, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                DoneCard(vm.result) { f -> install(ctx, f) }
            }

            AnimatedVisibility(vm.phase == Phase.Failed, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Notice("Ошибка: ${vm.error ?: "неизвестно"}", error = true)
            }
        }
    }
}

@Composable
private fun Hero() {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(60.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("B", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
            Column {
                Text(
                    "Моды для Super Bear Adventure", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    "Пропатчи игру один раз — дальше моды ставятся простой папкой.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }
    }
}

@Composable
private fun StepCard(n: Int, title: String, done: Boolean, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = CircleShape, modifier = Modifier.size(32.dp),
                    color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (done) Icon(Icons.Filled.Check, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        else Text("$n", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun CheckRow(text: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(
            if (ok) Icons.Filled.Check else Icons.Filled.Warning, null, Modifier.size(20.dp),
            tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun Notice(text: String, error: Boolean) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
        ),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Filled.Warning, null, tint = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer)
            Text(
                text, style = MaterialTheme.typography.bodyMedium,
                color = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
            )
        }
    }
}

@Composable
private fun LogBox(lines: List<String>) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            lines.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun DoneCard(file: File?, onInstall: (File) -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Готово!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onTertiaryContainer)
            Text(
                file?.name ?: "", style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Text(
                "Подпись у этого APK другая, поэтому оригинальную игру нужно сначала удалить. " +
                    "Потом нажми «Установить». Если Android попросит разрешение на установку, выдай его и нажми кнопку ещё раз.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Button(onClick = { if (file != null) onInstall(file) }, enabled = file != null) { Text("Установить") }
        }
    }
}

private fun install(ctx: Context, f: File) {
    if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return
    }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}
