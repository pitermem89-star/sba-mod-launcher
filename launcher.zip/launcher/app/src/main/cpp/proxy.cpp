#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>

#define TAG "BeariteProxy"

// Эта библиотека подставляется вместо libmain.so игры:
// сначала грузит загрузчик модов, потом настоящий libmain.
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    void* loader = dlopen("libbearite.so", RTLD_NOW | RTLD_GLOBAL);
    if (!loader) __android_log_print(ANDROID_LOG_ERROR, TAG, "libbearite.so: %s", dlerror());

    void* orig = dlopen("libmain_orig.so", RTLD_NOW | RTLD_GLOBAL);
    if (!orig) {
        __android_log_print(ANDROID_LOG_ERROR, TAG, "libmain_orig.so: %s", dlerror());
        return JNI_VERSION_1_6;
    }
    using Fn = jint (*)(JavaVM*, void*);
    Fn real = reinterpret_cast<Fn>(dlsym(orig, "JNI_OnLoad"));
    return real ? real(vm, reserved) : JNI_VERSION_1_6;
}
