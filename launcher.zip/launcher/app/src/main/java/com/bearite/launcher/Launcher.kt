package com.bearite.launcher

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.android.apksig.ApkSigner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.IOException
import java.io.OutputStream
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

// ======================================================================
// НАСТРОЙКИ. Если что-то не работает, сначала проверь здесь.
// ======================================================================
object Config {
    const val GAME_PACKAGE = "com.Earthkwak.Platformer"
    const val GAME_LABEL = "Super Bear Adventure"

    // Запасной вариант: если загрузчика нет внутри лаунчера, берём файл отсюда.
    const val LOCAL_LOADER = "/storage/emulated/0/Bearite/libbearite.so"

    // Здесь лежат моды: Bearite/mods/<папка мода>/mod.json
    const val MODS_DIR = "/storage/emulated/0/Bearite/mods"
}

private const val LOADER_LIB = "libbearite.so"
private const val PROXY_LIB = "libsbaproxy.so"
private val ABIS = listOf("arm64-v8a", "armeabi-v7a")

// ======================================================================
// Игра
// ======================================================================
data class GameInfo(val pkg: String, val label: String, val version: String, val apks: List<String>, val patched: Boolean)

object Game {
    fun find(ctx: Context): GameInfo? {
        val pm = ctx.packageManager
        val all = pm.getInstalledApplications(0)
        val app = all.firstOrNull { it.packageName == Config.GAME_PACKAGE }
            ?: all.firstOrNull { pm.getApplicationLabel(it).toString().contains(Config.GAME_LABEL, true) }
            ?: return null
        val version = runCatching { pm.getPackageInfo(app.packageName, 0).versionName }.getOrNull() ?: "?"
        val apks = buildList {
            add(app.sourceDir)
            app.splitSourceDirs?.let { addAll(it) }
        }
        val patched = apks.any { p ->
            runCatching {
                ZipFile(p).use { z -> ABIS.any { z.getEntry("lib/$it/$LOADER_LIB") != null } }
            }.getOrDefault(false)
        }
        return GameInfo(app.packageName, pm.getApplicationLabel(app).toString(), version, apks, patched)
    }
}

// ======================================================================
// Подпись. Ключ создаётся один раз на телефоне.
// ======================================================================
object Signer {
    private fun load(ctx: Context): Pair<PrivateKey, X509Certificate> {
        val kf = File(ctx.filesDir, "sign.key")
        val cf = File(ctx.filesDir, "sign.crt")
        if (!kf.exists() || !cf.exists()) generate(kf, cf)
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(cf.readBytes())) as X509Certificate
        return key to cert
    }

    private fun generate(kf: File, cf: File) {
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048)
        val kp = gen.generateKeyPair()
        val name = X500Name("CN=Bearite Launcher")
        val now = System.currentTimeMillis()
        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now), Date(now - 86_400_000L),
            Date(now + 36_500L * 86_400_000L), name, kp.public,
        )
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        kf.writeBytes(kp.private.encoded)
        cf.writeBytes(cert.encoded)
    }

    fun sign(ctx: Context, input: File, output: File) {
        val (key, cert) = load(ctx)
        val cfg = ApkSigner.SignerConfig.Builder("bearite", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input)
            .setOutputApk(output)
            .setMinSdkVersion(28)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }

    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    /** true, если игры нет на телефоне или она уже подписана нашим ключом. */
    fun isSignedByUs(ctx: Context, pkg: String): Boolean {
        val info = try {
            ctx.packageManager.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
        } catch (e: PackageManager.NameNotFoundException) {
            return true
        }
        val installed = info.signingInfo?.apkContentsSigners?.map { sha(it.toByteArray()) } ?: return false
        return installed.size == 1 && installed[0] == sha(load(ctx).second.encoded)
    }
}

// ======================================================================
// Патч APK: libmain.so -> libmain_orig.so, вместо него наш прокси,
// рядом кладём libbearite.so. Остальное не трогаем.
// ======================================================================
class CountingOut(out: OutputStream) : FilterOutputStream(out) {
    var count = 0L
    override fun write(b: Int) { out.write(b); count++ }
    override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
}

object Patcher {
    fun inject(ctx: Context, game: GameInfo, loader: File, work: File): List<File> {
        val abi = Build.SUPPORTED_ABIS.firstOrNull { it in ABIS }
            ?: throw IllegalStateException("эта архитектура телефона не поддерживается")
        val proxy = File(ctx.applicationInfo.nativeLibraryDir, PROXY_LIB)
        if (!proxy.exists()) throw IllegalStateException("в лаунчере нет прокси-библиотеки")
        val target = game.apks.firstOrNull { apk ->
            ZipFile(apk).use { it.getEntry("lib/$abi/libmain.so") != null }
        } ?: throw IllegalStateException("в игре нет lib/$abi/libmain.so")

        val out = mutableListOf<File>()
        game.apks.forEachIndexed { i, apk ->
            val dst = File(work, if (i == 0) "base.apk" else "split$i.apk")
            if (apk == target) rewrite(apk, dst, abi, proxy.readBytes(), loader.readBytes())
            else File(apk).copyTo(dst, overwrite = true)
            out += dst
        }
        return out
    }

    private fun rewrite(src: String, dst: File, abi: String, proxy: ByteArray, loader: ByteArray) {
        val mainName = "lib/$abi/libmain.so"
        val origName = "lib/$abi/libmain_orig.so"
        val loaderName = "lib/$abi/$LOADER_LIB"
        ZipFile(src).use { zf ->
            val already = zf.getEntry(origName) != null
            val co = CountingOut(BufferedOutputStream(FileOutputStream(dst), 1 shl 16))
            ZipOutputStream(co).use { zos ->
                zos.setLevel(Deflater.BEST_SPEED)
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    if (e.isDirectory) continue
                    when (e.name) {
                        mainName -> {
                            if (!already) putStored(zos, co, origName, zf.getInputStream(e).use { it.readBytes() })
                            putStored(zos, co, mainName, proxy)
                        }
                        loaderName -> Unit
                        else -> copyEntry(zos, co, zf, e)
                    }
                }
                putStored(zos, co, loaderName, loader)
            }
        }
    }

    // Библиотеки .so внутри APK должны лежать без сжатия и по границе 4 КБ.
    private fun alignExtra(offset: Long, nameBytes: Int, align: Int): ByteArray {
        var pad = ((align - (offset + 30 + nameBytes) % align) % align).toInt()
        if (pad == 0) return ByteArray(0)
        if (pad < 4) pad += align
        val x = ByteArray(pad)
        x[0] = 0x35
        x[1] = 0xD9.toByte()
        x[2] = ((pad - 4) and 0xFF).toByte()
        x[3] = (((pad - 4) shr 8) and 0xFF).toByte()
        return x
    }

    private fun alignFor(name: String) = if (name.endsWith(".so")) 4096 else 4

    private fun putStored(zos: ZipOutputStream, co: CountingOut, name: String, data: ByteArray) {
        zos.closeEntry()
        val e = ZipEntry(name)
        e.method = ZipEntry.STORED
        e.size = data.size.toLong()
        e.compressedSize = e.size
        val crc = CRC32()
        crc.update(data)
        e.crc = crc.value
        e.extra = alignExtra(co.count, name.toByteArray().size, alignFor(name))
        zos.putNextEntry(e)
        zos.write(data)
        zos.closeEntry()
    }

    private fun copyEntry(zos: ZipOutputStream, co: CountingOut, zf: ZipFile, e: ZipEntry) {
        if (e.method == ZipEntry.STORED) {
            zos.closeEntry()
            val n = ZipEntry(e.name)
            n.method = ZipEntry.STORED
            n.size = e.size
            n.compressedSize = e.size
            n.crc = e.crc
            n.extra = alignExtra(co.count, e.name.toByteArray().size, alignFor(e.name))
            zos.putNextEntry(n)
        } else {
            zos.putNextEntry(ZipEntry(e.name))
        }
        zf.getInputStream(e).use { it.copyTo(zos) }
        zos.closeEntry()
    }
}

// ======================================================================
// Загрузчик модов (libbearite.so)
// ======================================================================
object Loader {
    /** Загрузчик вшит в лаунчер при сборке (assets/libbearite.so). */
    fun get(ctx: Context): File {
        val cache = File(ctx.filesDir, LOADER_LIB)
        try {
            ctx.assets.open(LOADER_LIB).use { i -> cache.outputStream().use { o -> i.copyTo(o) } }
            if (cache.length() > 0) return cache
        } catch (e: IOException) {
            // нет во встроенных файлах, пробуем запасной вариант
        }
        val local = File(Config.LOCAL_LOADER)
        if (local.exists() && local.length() > 0) {
            local.copyTo(cache, overwrite = true)
            return cache
        }
        throw IOException("внутри лаунчера нет загрузчика модов (libbearite.so): пересобери лаунчер новым воркфлоу")
    }
}

// ======================================================================
// Установка через системный установщик
// ======================================================================
object InstallResult {
    val text = MutableStateFlow<String?>(null)
    val done = MutableStateFlow(false)
}

object Installer {
    const val ACTION = "com.bearite.launcher.INSTALL_RESULT"

    fun install(ctx: Context, apks: List<File>) {
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            for (f in apks) {
                f.inputStream().use { i ->
                    s.openWrite(f.name, 0, f.length()).use { o ->
                        i.copyTo(o)
                        s.fsync(o)
                    }
                }
            }
            val intent = Intent(ctx, InstallReceiver::class.java).setAction(ACTION)
            val pending = PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            s.commit(pending.intentSender)
        }
    }
}

class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = IntentCompat.getParcelableExtra(i, Intent.EXTRA_INTENT, Intent::class.java)
                confirm?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(it) }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                InstallResult.done.value = true
                InstallResult.text.value = "Готово! Игра пропатчена, можно запускать."
            }
            else -> InstallResult.text.value =
                "Установка не удалась: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "неизвестная ошибка")
        }
    }
}

// ======================================================================
// Моды
// ======================================================================
data class Mod(val dir: File, val name: String, val version: String, val author: String, val enabled: Boolean)

object Mods {
    fun list(): List<Mod> {
        val root = File(Config.MODS_DIR).apply { mkdirs() }
        return (root.listFiles() ?: emptyArray()).filter { it.isDirectory }.mapNotNull { d ->
            val on = File(d, "mod.json")
            val off = File(d, "mod.json.disabled")
            val f = when {
                on.exists() -> on
                off.exists() -> off
                else -> return@mapNotNull null
            }
            val j = runCatching { JSONObject(f.readText()) }.getOrNull() ?: return@mapNotNull null
            Mod(d, j.optString("name", d.name), j.optString("version"), j.optString("author"), f == on)
        }.sortedBy { it.name.lowercase() }
    }

    fun setEnabled(m: Mod, on: Boolean) {
        val a = File(m.dir, "mod.json")
        val b = File(m.dir, "mod.json.disabled")
        if (on) { if (b.exists()) b.renameTo(a) } else { if (a.exists()) a.renameTo(b) }
    }

    /** Ставит мод из .zip (в архиве должен быть mod.json). Возвращает название мода. */
    fun installZip(ctx: Context, uri: Uri): String {
        val files = mutableListOf<Pair<String, ByteArray>>()
        ctx.contentResolver.openInputStream(uri)!!.use { raw ->
            ZipInputStream(raw).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (!e.isDirectory) files += e.name to z.readBytes()
                    e = z.nextEntry
                }
            }
        }
        val manifest = files.filter { it.first == "mod.json" || it.first.endsWith("/mod.json") }
            .minByOrNull { it.first.length } ?: throw IOException("в архиве нет mod.json")
        val prefix = manifest.first.removeSuffix("mod.json")
        val j = JSONObject(String(manifest.second))
        val id = j.optString("id")
        if (!Regex("[A-Za-z0-9._-]+").matches(id)) throw IOException("в mod.json нет корректного id")

        val target = File(Config.MODS_DIR, id)
        val keep = File(target, "settings.json").takeIf { it.exists() }?.readBytes()
        target.deleteRecursively()
        target.mkdirs()
        for ((name, data) in files) {
            if (!name.startsWith(prefix)) continue
            val f = File(target, name.removePrefix(prefix))
            if (!f.canonicalPath.startsWith(target.canonicalPath + File.separator)) continue
            f.parentFile?.mkdirs()
            f.writeBytes(data)
        }
        if (keep != null) File(target, "settings.json").writeBytes(keep)
        return j.optString("name", id)
    }
}

// ======================================================================
// Логика экрана
// ======================================================================
data class UiState(
    val game: GameInfo? = null,
    val storageOk: Boolean = false,
    val busy: Boolean = false,
    val status: String = "",          // что делаем прямо сейчас
    val ready: List<File> = emptyList(), // собранный APK, ждёт установки
    val mods: List<Mod> = emptyList(),
    val message: String? = null,
    val askDelete: Boolean = false,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            InstallResult.text.collect { t ->
                if (t != null) {
                    val ok = InstallResult.done.value
                    _state.update { it.copy(message = t, ready = if (ok) emptyList() else it.ready, status = "") }
                    InstallResult.text.value = null
                    InstallResult.done.value = false
                    refresh()
                }
            }
        }
    }

    private fun say(t: String) = _state.update { it.copy(message = t) }
    fun clearMessage() = _state.update { it.copy(message = null) }
    private fun open(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    private fun storageGranted() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = storageGranted()
            val g = Game.find(ctx)
            val mods = if (ok) Mods.list() else emptyList()
            _state.update { it.copy(game = g, storageOk = ok, mods = mods) }
        }
    }

    fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30)
            open(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
    }

    /** Главная кнопка: собирает патч, а потом сразу пытается установить. */
    fun patch() {
        val game = _state.value.game ?: return say("Игра не найдена. Сначала установи Super Bear Adventure.")
        if (_state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, ready = emptyList()) }
            try {
                _state.update { it.copy(status = "Готовлю загрузчик модов…") }
                val loader = Loader.get(ctx)
                _state.update { it.copy(status = "Встраиваю загрузчик в игру…") }
                val work = File(ctx.cacheDir, "patch").apply { deleteRecursively(); mkdirs() }
                val unsigned = Patcher.inject(ctx, game, loader, work)
                _state.update { it.copy(status = "Подписываю…") }
                val signed = unsigned.map { f -> File(work, "signed_" + f.name).also { Signer.sign(ctx, f, it); f.delete() } }
                _state.update { it.copy(ready = signed, busy = false, status = "") }
                install()
            } catch (e: Throwable) {
                _state.update { it.copy(busy = false, status = "") }
                say("Ошибка: ${e.message}")
            }
        }
    }

    fun install() {
        val s = _state.value
        if (s.ready.isEmpty()) return
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            open(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")))
            return say("Разреши установку из лаунчера и нажми «Установить» снова.")
        }
        val g = s.game
        if (g != null && !Signer.isSignedByUs(ctx, g.pkg)) {
            _state.update { it.copy(askDelete = true) }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(status = "Устанавливаю…") }
            try { Installer.install(ctx, s.ready) } catch (e: Throwable) { say("Ошибка установки: ${e.message}") }
        }
    }

    fun deleteOriginal() {
        _state.update { it.copy(askDelete = false) }
        val pkg = _state.value.game?.pkg ?: return
        open(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        say("После удаления вернись сюда и нажми «Установить».")
    }

    fun dismissDelete() = _state.update { it.copy(askDelete = false) }

    fun launchGame() {
        val pkg = _state.value.game?.pkg ?: return
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { open(it) }
    }

    fun setEnabled(m: Mod, on: Boolean) {
        viewModelScope.launch(Dispatchers.IO) { Mods.setEnabled(m, on); refresh() }
    }

    fun importMod(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try { say("Мод «${Mods.installZip(ctx, uri)}» добавлен") } catch (e: Throwable) { say("Не получилось: ${e.message}") }
            refresh()
        }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherApp(vm) }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}

// ======================================================================
// Интерфейс: Material 3, один экран
// ======================================================================
@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherApp(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(s.message) {
        s.message?.let { snack.showSnackbar(it); vm.clearMessage() }
    }
    val pickMod = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.importMod(it) } }

    LauncherTheme {
        Scaffold(
            topBar = { CenterAlignedTopAppBar(title = { Text("Bearite Launcher") }) },
            snackbarHost = { SnackbarHost(snack) },
        ) { pad ->
            LazyColumn(
                Modifier.padding(pad).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item { GameCard(s, vm) }
                if (!s.storageOk) item { StorageCard(vm) }
                item { Text("Моды", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }
                if (s.storageOk) {
                    if (s.mods.isEmpty()) {
                        item {
                            Text(
                                "Модов пока нет. Нажми «Добавить мод» и выбери .zip.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    items(s.mods, key = { it.dir.path }) { mod ->
                        ElevatedCard {
                            ListItem(
                                headlineContent = { Text(mod.name) },
                                supportingContent = {
                                    val line = listOf(
                                        mod.version.takeIf { it.isNotBlank() }?.let { "v$it" },
                                        mod.author.takeIf { it.isNotBlank() },
                                    ).filterNotNull().joinToString(" · ")
                                    if (line.isNotEmpty()) Text(line)
                                },
                                trailingContent = { Switch(checked = mod.enabled, onCheckedChange = { vm.setEnabled(mod, it) }) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            )
                        }
                    }
                    item {
                        OutlinedButton(onClick = { pickMod.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(Modifier.padding(4.dp))
                            Text("Добавить мод")
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }

        if (s.askDelete) {
            AlertDialog(
                onDismissRequest = vm::dismissDelete,
                title = { Text("Нужно удалить оригинал") },
                text = {
                    Text(
                        "Пропатченная игра подписана другим ключом, поэтому поверх оригинала она не встанет. " +
                            "Оригинал нужно удалить. Сохранения на телефоне пропадут, если они не в облаке.",
                    )
                },
                confirmButton = { TextButton(onClick = vm::deleteOriginal) { Text("Удалить") } },
                dismissButton = { TextButton(onClick = vm::dismissDelete) { Text("Отмена") } },
            )
        }
    }
}

@Composable
fun GameCard(s: UiState, vm: MainViewModel) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(s.game?.label ?: "Игра не найдена", style = MaterialTheme.typography.titleLarge)
            Text(
                s.game?.let { "версия ${it.version}" } ?: "Установи Super Bear Adventure и вернись сюда",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (s.game != null) {
                AssistChip(
                    onClick = {},
                    label = { Text(if (s.game.patched) "Патч установлен" else "Без патча") },
                    leadingIcon = {
                        Icon(
                            if (s.game.patched) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                            contentDescription = null,
                        )
                    },
                )
            }
            if (s.busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(s.status, style = MaterialTheme.typography.bodyMedium)
            } else if (s.status.isNotEmpty()) {
                Text(s.status, style = MaterialTheme.typography.bodyMedium)
            }
            if (s.ready.isNotEmpty() && !s.busy) {
                Button(onClick = vm::install, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Download, contentDescription = null)
                    Spacer(Modifier.padding(4.dp))
                    Text("Установить")
                }
            } else {
                Button(onClick = vm::patch, enabled = s.game != null && !s.busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Build, contentDescription = null)
                    Spacer(Modifier.padding(4.dp))
                    Text(if (s.game?.patched == true) "Пропатчить заново" else "Пропатчить игру")
                }
            }
            if (s.game?.patched == true && !s.busy) {
                OutlinedButton(onClick = vm::launchGame, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.padding(4.dp))
                    Text("Запустить игру")
                }
            }
        }
    }
}

@Composable
fun StorageCard(vm: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Нужен доступ ко всем файлам, чтобы видеть папку модов (Bearite/mods).")
            Button(onClick = vm::requestStorage) { Text("Разрешить") }
        }
    }
}
